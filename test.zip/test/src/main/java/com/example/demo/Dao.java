package com.example.demo;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;

public interface Dao {

	public been saveData(been been);

	public been list();

	public been delete(int id);

	public been edit(int id);

	public been updateData(been been,int id);

	public been findByUsername(been been);


}
