package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class DaoImpl implements Dao{
			
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	@Autowired
	DataSource datasource;
	
	@Override
	public been saveData(been been) {
		boolean email=false;
			try {
			   String Uemail=been.getEmail();
				 int useremailCount = jdbcTemplate.queryForObject(queryutill.Emailcheck, new Object[] { Uemail }, Integer.class);
				 if(useremailCount==0) {
				   jdbcTemplate.update(queryutill.save, new Object[] {been.getName(),been.getEmail(),Integer.parseInt(been.getAge()),been.getDob(),been.getGender() });
				   been.setSucess(true);
				 }else {
					 System.out.println("Email ia already exited.......!");
					 been.setEmailerror(email=true);
				 }
			} catch (Exception e) {
				e.printStackTrace();
			}
			

			return been;
	}

	@Override
	public been list() {
		List<been> list1 = new ArrayList<been>();
		been been =new been();
		try {
		  list1=jdbcTemplate.query(queryutill.GET_List,new Object[]{},
				new BeanPropertyRowMapper<been>(been.class));
		  been.setList1(list1);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return been;
	}

	@Override
	public been delete(int id) {
		been been =new been();
		try {
			 jdbcTemplate.update(queryutill.delete, new Object[] {id});	
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return been;
	}
	
	@Override
	public been edit(int id) {
		List<been> editlist = new ArrayList<been>();
		been been =new been();
		try {
			editlist=jdbcTemplate.query(queryutill.Edit,new Object[]{ id},
				new BeanPropertyRowMapper<been>(been.class));
		  been.setEditlist(editlist);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return been;
	}
	@Override
	public been updateData(been been,int id) {
		
			try {
				 String Uemail=been.getEmail();
				 int useremailCount = jdbcTemplate.queryForObject(queryutill.Emailcheck, new Object[] { Uemail }, Integer.class);
				 if(useremailCount==1) {
				 jdbcTemplate.update(queryutill.update, new Object[] {been.getName(),been.getEmail(),Integer.parseInt(been.getAge()),been.getDob(),been.getGender(),id});
				 been.setSucess(true);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			

			return been;
	}

	@Override
	public been findByUsername(been been) {
	    try {
	        String username = been.getUsername();
	        String password = been.getPassword();
	        boolean logged=false;
	        boolean pass=false;
	        boolean user=false;
	        int userCount = jdbcTemplate.queryForObject(queryutill.userCheck, new Object[] { username }, Integer.class);

	        if (userCount ==1) {
	        	String passvalid = jdbcTemplate.queryForObject(queryutill.passCheck, new Object[] { username }, String.class);
	        	if (passvalid.equals(password)) {
	        		
	        		System.out.println("Usernme And Password are Correct!--------");
	        		been.setLogged(logged=true);
	        	}else {
	        		System.out.println("Password are InCorrect!--------");
	        		been.setPasserror(pass=true);
	        	}
	        		
	        } else {
	        	System.out.println("Usernme Not Found!--------");
	        	been.setUsererror(user=true);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return been;
	}

	
}
