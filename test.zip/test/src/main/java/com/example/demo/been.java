package com.example.demo;

import java.util.List;

public class been {
private String msg;
public String getMsg() {
	return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}
public boolean isSucess() {
	return Sucess;
}
public void setSucess(boolean sucess) {
	Sucess = sucess;
}
private boolean Sucess;
private String bname;
public String getBname() {
	return bname;
}
public void setBname(String bname) {
	this.bname = bname;
}
private boolean Sucessdata;
public boolean isSucessdata() {
	return Sucessdata;
}
public void setSucessdata(boolean sucessdata) {
	Sucessdata = sucessdata;
}
private String name;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
private String email;
private String alert;
public String getAlert() {
	return alert;
}
public void setAlert(String alert) {
	this.alert = alert;
}
private String age;
private String dob;
private String gender;
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
private List<been> list1;

public List<been> getList1() {
	return list1;
}
public void setList1(List<been> list1) {
	this.list1 = list1;
}
private int id;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
private List<been> editlist;
public List<been> getEditlist() {
	return editlist;
}
public void setEditlist(List<been> editlist) {
	this.editlist = editlist;
}

private String username;
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
private String password;

private boolean logged;
public boolean isLogged() {
	return logged;
}
public void setLogged(boolean logged) {
	this.logged = logged;
}
private boolean passerror;
public boolean isPasserror() {
	return passerror;
}
public void setPasserror(boolean passerror) {
	this.passerror = passerror;
}
public boolean isUsererror() {
	return usererror;
}
public void setUsererror(boolean usererror) {
	this.usererror = usererror;
}
public boolean isEmailerror() {
	return emailerror;
}
public void setEmailerror(boolean emailerror) {
	this.emailerror = emailerror;
}
private boolean usererror;
private boolean emailerror;

}
