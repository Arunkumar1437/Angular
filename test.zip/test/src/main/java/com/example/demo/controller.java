package com.example.demo;

import java.net.http.HttpHeaders;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class controller {
	 
	 @Autowired
		private service service ;
	
	
	 
	 @GetMapping("/api/list")
	    public been list() {
		 boolean sucess=false;
		 been rb = null;
		 try {			 
				rb = service.list();
				 String msg="Hello from the backend!";
				    String nam="kumar";
				    rb.setMsg(msg);
				    rb.setBname(nam);
				    rb.setSucess(sucess=true);
		 } catch (Exception e) {
				e.printStackTrace();
			}
	        return rb;
	    }
	    @PostMapping("/api/save")
	    public ResponseEntity<?> saveData(@RequestBody been been) {
	    	boolean sucess=false;
	    	service.saveData(been);
	    	String message="Data Saved Sucess";
	    	been.setAlert(message);
	    	been.setSucessdata(sucess=true);
	    	return ResponseEntity.ok(been);
	    }
	    @DeleteMapping("/api/delete/{id}")
	    public been delete(@PathVariable int id) {
	    	been been = new been();
	        boolean success = false;

	        try {
	            service.delete(id);
	            been.setSucess(success = true);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return been;
	    }
	    
	    @GetMapping("/api/edit/{id}")
	    public been getEntityById(@PathVariable int id) {
	    	been getbeen=new  been();
	    	getbeen= service.edit(id);
	        return getbeen;
	    }
	    
	    @PostMapping("/api/update/{id}")
	    public ResponseEntity<?> updateData(@RequestBody been been, @PathVariable int id) {
	        boolean success = false;
	        service.updateData(been, id);
	        String message = "Data updated Successfully";
	        been.setAlert(message);
	        return ResponseEntity.ok(been);
	    }
	    
	    @PostMapping("/api/login")
	    public ResponseEntity<?> login(@RequestBody been been) {
	    	service.findByUsername(been);
	    	return ResponseEntity.ok(been);
	    }   
}