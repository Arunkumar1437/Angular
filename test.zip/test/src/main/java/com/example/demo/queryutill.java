package com.example.demo;

public class queryutill {

	public static  String save = "INSERT INTO detail_data (name,email,age,dob,gender) VALUES (?,?,?,?,?)";
	
	public static  String GET_List = "select * from detail_data order by id";
	
	public static  String delete = "delete from detail_data where id=?";
	
	public static  String Edit = "select * from detail_data where id=?";
	
	public static  String update = "UPDATE detail_data SET name = ?, email = ?, age = ?,dob=?,gender=? WHERE id = ?";
	
	public static  String userCheck = "select count(user_id) from user_table where user_id=?";
		
	public static  String passCheck = "select pass from user_table where user_id=?";
	
	public static  String Emailcheck = "select count(email) from detail_data where email=?";
	
}
