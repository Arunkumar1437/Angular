package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.stereotype.Service;
@Service
public class serviceImpl implements service{
	@Autowired
	Dao dao;
	
	@Override
	public been saveData(been been) {
		return dao.saveData(been);
	}
	public been list() {
		return dao.list();
	}
	public been delete(int id){
		return dao.delete(id);
	}
	@Override
	public been edit(int id) {
		return dao.edit(id);
	}
	@Override
	public been updateData(been been,int id) {
		return dao.updateData(been,id);
	}
	@Override
	public been findByUsername(been been) {
		// TODO Auto-generated method stub
		return dao.findByUsername(been);
	}
}
